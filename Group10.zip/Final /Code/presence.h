// Nam

#include <iostream>
#include <string>
using namespace std;

int __Next_token(string &,string &);

class Presence
{
protected:
    string course_code;
    string student_id;
    int year;
    int semeter;
    int week;
};
