#include "UI.h"
#include "SMS.h"
#include "user.h"
#include "course.h"

using namespace std;

int main() {
    User_interface UI;
    UI.Program();
    return 0;
}


